//Chris Fischer
//CS210-Project 3
//A program that reads an input file and tacks the frequency of each
//and has a menu to seach and display frequencies 


#include <iostream>
#include <map>
#include <fstream>
#include <string>

using namespace std;

class soldItems {
public:
    // Reads the input file
    void readFile(string filename) {
        //open file
        ifstream inputFile("CS210ProjectThreeInputFile.txt");
        if (inputFile.fail()) {
            //return error if file cannot be opened
            cout << "Error: Could not open the file" << filename << endl; 
            return;
        }
        string item; //variable for item name
        while (inputFile >> item) {
            frequency[item]++;  //counts the frequency of the item
        }
        inputFile.close();   //close the file
    }

    //Return item frequency
    int printItemFrequency(string item) {
        return frequency[item];
    }


    // Prints a list of all items and frequencies
    void printAllItems() {
        for (auto item = frequency.begin(); item != frequency.end(); ++item) {
            cout << item->first << ": " << item->second << endl;
        }
    }

    // Prints a histogram of all items and frequencies
    void printHistogram() {
        for (auto item = frequency.begin(); item != frequency.end(); ++item) {
            cout << item->first << " ";
            for (int i = 0; i < item->second; i++) {
                cout << "+";
            }
            cout << endl;
        }
    }

    //Save data to a backup file
    void backupFile(string filename) {
        ofstream outputFile("frequency.dat");
        if (outputFile.fail()) {
            cout << "Error: Could not open file " << filename << endl;
            return;
        }
        for (auto item = frequency.begin(); item != frequency.end(); ++item) {
            outputFile << item->first << ": " << item->second << endl;
        }
        cout << "Data backed up to file frequency.dat";

        outputFile.close();
    }

    private:
    map<string, int> frequency;   //map for item and frequency
};



int main() {
    //create object
    soldItems cornerGrocer;

    // Process the input file
    cornerGrocer.readFile("itemssold.txt");

    // Main menu loop
    bool runProgram = true;
    while (runProgram){
    
        // Display menu options
        cout << endl;
        cout << "Grocery Tracker Main Menu" << endl;
        cout << "1. Look up an individual item's frequency" << endl;
        cout << "2. Print list of all items and frequencies" << endl;
        cout << "3. Print frequency histogram" << endl;
        cout << "4. Exit the program" << endl;
        

        // Get menu input
        int select;
        cout << "Enter a selection from the menu: ";
        cin >> select;

        // Perform user input selection
        switch (select) {
        case 1: {
            string item;
            cout << "Enter a grocery item to look up: ";
            cin >> item;
            int freq = cornerGrocer.printItemFrequency(item);
            cout << "Frequency of " << item << ": " << freq << endl;
            break;
        }
        case 2: {
            cornerGrocer.printAllItems();   
            break;
        }
        case 3: {
            cornerGrocer.printHistogram(); 
            break;
        }
        case 4: {
            cornerGrocer.backupFile("frequency.dat");
            break;
        }
        default: {
            cout << "Selection invalid. Please enter a valid option." << endl;
            break;
        } 
        }
    }
    return 0;
}